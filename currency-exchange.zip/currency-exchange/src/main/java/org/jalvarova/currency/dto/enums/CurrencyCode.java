package org.jalvarova.currency.dto.enums;

public enum CurrencyCode {
    ARS,
    BRL,
    CAD,
    CLP,
    PEN,
    USD,
    JPY,
    EUR,
    VEF
}

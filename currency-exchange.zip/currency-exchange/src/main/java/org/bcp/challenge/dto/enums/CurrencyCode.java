package org.bcp.challenge.dto.enums;

public enum CurrencyCode {
    ARS,
    BRL,
    CAD,
    CLP,
    PEN,
    USD,
    JPY,
    EUR,
    VEF
}
